// Definiendo el objeto
let persona = {};

// Atributos del objeto
persona.nombre = prompt("Ingrese su nombre:");
persona.edad = prompt("Ingrese su edad:");
persona.dni = prompt("Ingrese su DNI:");
persona.domicilio = prompt("Ingrese su domicilio:");
persona.hijos = prompt("¿Cuántos hijos tiene?");
persona.profesion = prompt("Ingrese su profesión:");

// Métodos del objeto
persona.saludar = function() {
  document.write("<p>¡Hola! " + this.nombre + "</p>");
};
persona.listar = function() {
  document.write("<ul>");
  document.write("<li>Nombre: " + this.nombre + "</li>");
  document.write("<li>Edad: " + this.edad + "</li>");
  document.write("<li>DNI: " + this.dni + "</li>");
  document.write("<li>Domicilio: " + this.domicilio + "</li>");
  document.write("<li>Hijos: " + this.hijos + "</li>");
  document.write("<li>Profesión: " + this.profesion + "</li>");
  document.write("</ul>");
};

// Llamando a los métodos
persona.saludar();
persona.listar();